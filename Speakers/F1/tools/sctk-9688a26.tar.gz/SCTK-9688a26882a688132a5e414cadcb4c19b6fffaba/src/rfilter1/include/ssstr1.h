/* file ssstr1.h */

#ifndef SSSTR1_HEADER
#define SSSTR1_HEADER

  struct substring
    {Char *start;
     Char *end;
    };
  typedef struct substring SUBSTRING;

#endif
